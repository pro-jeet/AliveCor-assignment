//
//  NetworkManager.swift
//  AliveCor-Assignment
//
//  Created by Jitesh Sharma on 17/05/21.
//  Copyright © 2021 Jitesh Sharma. All rights reserved.
//

import Foundation

class NetworkManager {
    
    static func fetchMovieDetails(fetchWithID id: String, completion: @escaping((MovieDetails)->())) {
        let url = URL(string: "\(MovieDBQueries.getMovieDetailsBaseURL)\(id)\(MovieDBQueries.getEnglishVersionTailURL)")!
        (URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let data = data {
                let jsonDecoder = JSONDecoder()
                do {
                    let movieDetails = try jsonDecoder.decode(MovieDetails.self, from: data)
                    completion(movieDetails)
                } catch {
                    print("Error in do-catch")
                    print(error.localizedDescription)
                }
            } else {
                print("No data")
                print(error?.localizedDescription)
            }
        }).resume()
    }
    
    static func fetchTrailerUrl(fetchWithID id: String, completion: @escaping((String)->())) {
        
        let url = URL(string: "\(MovieDBQueries.getMovieDetailsBaseURL)\(id)\(MovieDBQueries.movieTrailerTailURL)")!
        
        (URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
            if let data = data {
                let jsonDecoder = JSONDecoder()
                
                do {
                    let json = try jsonDecoder.decode(MovieTrailer.self, from: data)
                    let key = json.results?.first?.key
                    if let key = key {
                        completion(key)
                    }
                } catch {
                    print(error.localizedDescription)
                }
            }
        })).resume()
    }
    
    func fetchExtraDetails(withID id: Int, completion: @escaping(([Results])->())) {
        // use id to fetch extra details from url
        // parse for Runtime & Genre
        // append to Results object, return object in closure
        
        let stringID = id.returnStringDescription()
        NetworkManager.fetchMovieDetails(fetchWithID: stringID) { (movieDetails) in
            
        }
    }
    
    static func fetchReleasedMovies(completion: @escaping(([Results])->())) {
        let url = URL(string: MovieDBQueries.getReleasedMovies)
        (URLSession.shared.dataTask(with: url!) { (data, response, err) in
            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    let movies = try  jsonDecoder.decode(JSONData.self, from: data)
                    if let results = movies.results {
                        completion(results)
                    }
                } catch {
                    print(err! as NSError)
                }
            } else {
                print(err?.localizedDescription)
            }
        }).resume()
    }
    
    static func fetchUpcomingMovies(completion: @escaping(([Results])->())) {
        let url = URL(string: MovieDBQueries.getUpcomingMovies)
        (URLSession.shared.dataTask(with: url!) { (data, response, err) in
            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    let movies = try  jsonDecoder.decode(JSONData.self, from: data)
                    if let results = movies.results {
                        completion(results)
                    }
                } catch {
                    print(err! as NSError)
                }
            } else {
                print(err?.localizedDescription)
            }
        }).resume()
    }
    
    static func fetchNowPlayingMovies(completion: @escaping(([Results])->())) {
        let url = URL(string: MovieDBQueries.getNowPlayingMovies)
        (URLSession.shared.dataTask(with: url!) { (data, response, err) in
            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    let movies = try  jsonDecoder.decode(JSONData.self, from: data)
                    if let results = movies.results {
                        completion(results)
                    }
                } catch {
                    print(err! as NSError)
                }
            } else {
                print(err?.localizedDescription)
            }
        }).resume()
    }
}
