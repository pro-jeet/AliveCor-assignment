//
//  SavedMovies+CoreDataClass.swift
//  AliveCor-Assignment
//
//  Created by Jitesh Sharma on 17/05/21.
//  Copyright © 2021 Jitesh Sharma. All rights reserved.
//

import Foundation
import CoreData

@objc(SavedMovies)
public class SavedMovies: NSManagedObject {

}
