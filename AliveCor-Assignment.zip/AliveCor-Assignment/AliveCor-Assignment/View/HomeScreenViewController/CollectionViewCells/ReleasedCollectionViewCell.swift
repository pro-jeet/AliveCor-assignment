//
//  ReleasedCollectionViewCell.swift
//  AliveCor-Assignment
//
//  Created by Jitesh Sharma on 17/05/21.
//  Copyright © 2021 Jitesh Sharma. All rights reserved.
//

import UIKit

class ReleasedCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var shadowView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    var id: String?
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        shadowView.addRoundedCorners()
        shadowView.backgroundColor = .orange
        shadowView.addRoundedCorners()
        shadowView.backgroundColor = UIColor.white.withAlphaComponent(0.15)
        imageView.addRoundedCorners()

    }
}
