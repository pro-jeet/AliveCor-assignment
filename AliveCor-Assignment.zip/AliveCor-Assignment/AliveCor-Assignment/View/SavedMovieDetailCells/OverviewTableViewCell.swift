//
//  OverviewTableViewCell.swift
//  AliveCor-Assignment
//
//  Created by Jitesh Sharma on 17/05/21.
//  Copyright © 2021 Jitesh Sharma. All rights reserved.
//

import Foundation
import UIKit


class OverviewTableViewCell: UITableViewCell {

    @IBOutlet weak var overview: UITextView!
    
    override func awakeFromNib() {
        var frame = overview.frame
        frame.size = overview.contentSize
        overview.frame = frame
    }
}
