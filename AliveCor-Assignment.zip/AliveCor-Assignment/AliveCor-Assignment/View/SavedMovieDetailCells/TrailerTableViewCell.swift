//
//  TrailerTableViewCell.swift
//  AliveCor-Assignment
//
//  Created by Jitesh Sharma on 17/05/21.
//  Copyright © 2021 Jitesh Sharma. All rights reserved.
//

import Foundation
import UIKit

class TrailerTableViewCell: UITableViewCell {
    @IBOutlet weak var playTrailerButton: UIButton!
    
    override func awakeFromNib() {
        playTrailerButton.clipsToBounds = true
        playTrailerButton.layer.cornerRadius = 8.0
    }

    @IBAction func playTrailerButtonDidTap() {
    }
}
