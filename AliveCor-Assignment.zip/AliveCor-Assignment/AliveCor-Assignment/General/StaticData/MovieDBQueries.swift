//
//  MovieDBQueries.swift
//  AliveCor-Assignment
//
//  Created by Jitesh Sharma on 17/05/21.
//  Copyright © 2021 Jitesh Sharma. All rights reserved.
//

import Foundation

class MovieDBQueries {
    static var baseURL = "https://api.themoviedb.org/3/"
    static var apiKey = "34c902e6393dc8d970be5340928602a7"
    static var getNowPlayingMovies = "https://api.themoviedb.org/3/movie/now_playing?api_key=34c902e6393dc8d970be5340928602a7&language=en-US&page=1"
    static var getReleasedMovies = "https://api.themoviedb.org/3/discover/movie?primary_release_date.gte=2014-09-15&primary_release_date.lte=2014-10-22&api_key=34c902e6393dc8d970be5340928602a7"
    static var getUpcomingMovies = "https://api.themoviedb.org/3/movie/upcoming?api_key=34c902e6393dc8d970be5340928602a7&language=en-US&page=1"
    static var getMovieDetailsBaseURL = "https://api.themoviedb.org/3/movie/"
    static var getEnglishVersionTailURL = "?api_key=34c902e6393dc8d970be5340928602a7&&language=en-US"
    static var getMovieCreditsTailURL = "/credits?api_key=34c902e6393dc8d970be5340928602a7"
    static var movieImageBaseURL = "https://image.tmdb.org/t/p/original"
    static var movieTrailerTailURL = "/videos?api_key=34c902e6393dc8d970be5340928602a7&language=en-US"
}


